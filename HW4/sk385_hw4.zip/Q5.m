%Question 5
clear all
syms x
fourierComp(((sin(x)).^2),-pi,pi,10)
func = x+pi
%fourierComp(func,-pi,0,100)
%hold on
%fourierComp(x,0,pi,100)
