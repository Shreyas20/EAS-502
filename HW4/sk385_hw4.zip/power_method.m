function [m,y_final]=power_method(A,x);
m=0;
n=length(x);
y_final=zeros(n,1);
y_final=x;
tol=1e-3;
while(1)
    mold=m;
 y_final=A*y_final;
 m=max(y_final);
 y_final=y_final/m;
 if (m-mold)<tol
     break;
 end
end
end